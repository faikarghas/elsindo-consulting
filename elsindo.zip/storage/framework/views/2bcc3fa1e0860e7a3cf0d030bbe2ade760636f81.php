<header>
    
    <menu>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="">About Us</a></li>
                        <li><a href="">Services</a></li>
                        <li><a href="">International Partners</a></li>
                        <li><a href="">Testimonial</a></li>
                        <li><a href="">Contact Us</a></li>
                        <li><a href="">Event</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </menu>
    
</header><?php /**PATH C:\Users\IMBA PC\OneDrive\Dokumen\dignite\elsindo-consulting\resources\views/client/components/presentational/header/index.blade.php ENDPATH**/ ?>