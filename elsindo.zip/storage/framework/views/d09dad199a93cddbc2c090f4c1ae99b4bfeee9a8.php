
<?php $__env->startSection('content'); ?>

<main page="home">
    <section class="section__first">
        <div  class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner">
                        <picture>
                            <source media="(max-width:650px)" srcset="<?php echo e(asset('images/banner/Landing-Page-Banner-Website-Cover-m.jpeg')); ?>">
                            <img src="<?php echo e(asset('images/banner/Landing-Page-Banner-Website-Cover.jpg')); ?>" alt="banner" width="100%">
                        </picture>
                    </div>
                    <div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
</main> 

<?php $__env->stopSection(); ?>



<?php echo $__env->make('client/components/layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IMBA PC\OneDrive\Dokumen\dignite\elsindo-consulting\resources\views/client/home/index.blade.php ENDPATH**/ ?>